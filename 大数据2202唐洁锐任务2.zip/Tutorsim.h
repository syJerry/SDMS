#pragma once
#include"Graph.h"
using namespace std;
class Tutorsim
{
public:
	void CreateGraph(string Vfilename, string Efilename);
	void GetSpotInfo();

private:
	Graph g;
};
